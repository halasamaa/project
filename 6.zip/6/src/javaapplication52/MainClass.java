/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
//package Chapter7.Overlapping;

import edu.rit.pj2.Task;
import edu.rit.pj2.example.MandelbrotSmp2;

/**
 *
 * @author ASUS
 */
public class MainClass {
    public static void main(String[] args) throws Exception{
           long t1,t2,tseq, tsmp1, tsmp2, tsmp3, tsmp4;
            float sup;
        
        Task seq = new MandelbrotSeq();
        Task smp = new MandelbrotSmp();
        Task smp2 = new MandelbrotSmp2();
        
        args = new String[8];
        args[0]="3200";
        args[1]="3200";
        args[2]="-0.75";
        args[3]="0";
        args[4]="1200";
        args[5]="1000";
        args[6]="0.4";
        args[7]="ms1200a.png";
        
        System.out.println("*************************");
        System.out.println("sequential");
        System.out.println("*************************");
         t1 = (int) System.currentTimeMillis();
        seq.main(args);
          t2 = (int) System.currentTimeMillis();
          tseq=t2-t1;
        System.out.println("*************************");
        System.out.println("parallel ");
        System.out.println("*************************");
         System.out.println("***1 thread**** ");
           
        smp.threads(1);
        t1 = (int) System.currentTimeMillis();
        smp.main(args);
        t2 = (int) System.currentTimeMillis();
        tsmp1=t2-t1;
   sup=(float)tseq/tsmp1;
      System.out.println("Speed Up using 1 thread: " + sup);
          System.out.println("***2 threads*** ");
        smp.threads(2);
         t1 = (int) System.currentTimeMillis();
        smp.main(args);
         t2 = (int) System.currentTimeMillis();
             tsmp2=t2-t1;
              sup=(float)tseq/tsmp2;
                 System.out.println("Speed Up using 2 thread: " + sup);
          System.out.println("***3 threads ***");
        smp.threads(3);
         t1 = (int) System.currentTimeMillis();
        smp.main(args);
       t2 = (int) System.currentTimeMillis();
         tsmp3=t2-t1;
          sup=(float)tseq/tsmp3;
             System.out.println("Speed Up using 3 thread: " + sup);
        System.out.println("***4 threads ***");
        smp.threads(4);
               t1 = (int) System.currentTimeMillis();
        smp.main(args);
               t2 = (int) System.currentTimeMillis();
         tsmp4=t2-t1;
          sup=(float)tseq/tsmp4;
   System.out.println("Speed Up using 4 thread: " + sup);
        
        System.out.println("*************************");
        System.out.println("parallel with overlapping");
        System.out.println("*************************");
        
             System.out.println("***1 threads*** ");
        smp2.threads(1);
         t1 = (int) System.currentTimeMillis();
        smp2.main(args);
         t2 = (int) System.currentTimeMillis();
             tsmp1=t2-t1;
              sup=(float)tseq/tsmp1;
                 System.out.println("Speed Up using 1 thread: " + sup);
                 
                 
             System.out.println("***2 threads*** ");
        smp2.threads(2);
         t1 = (int) System.currentTimeMillis();
        smp2.main(args);
         t2 = (int) System.currentTimeMillis();
             tsmp2=t2-t1;
              sup=(float)tseq/tsmp2;
                 System.out.println("Speed Up using 2 thread: " + sup);
                 
                 
             System.out.println("***3 threads*** ");
        smp2.threads(3);
         t1 = (int) System.currentTimeMillis();
        smp2.main(args);
         t2 = (int) System.currentTimeMillis();
             tsmp3=t2-t1;
              sup=(float)tseq/tsmp3;
                 System.out.println("Speed Up using 3 thread: " + sup);
                 
                 
             System.out.println("***4 threads*** ");
        smp2.threads(4);
         t1 = (int) System.currentTimeMillis();
        smp2.main(args);
         t2 = (int) System.currentTimeMillis();
             tsmp4=t2-t1;
              sup=(float)tseq/tsmp4;
                 System.out.println("Speed Up using 4 thread: " + sup);
    }
    }
    
    

